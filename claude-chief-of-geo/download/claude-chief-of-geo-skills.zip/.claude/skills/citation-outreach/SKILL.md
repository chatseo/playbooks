---
name: citation-outreach
description: Turn geo-queries.md into outreach. Use when asked to get listed in rankings, find GEO partners, or run the ranking swap.
---
1. From geo-queries.md, take every ranking page where we are NOT listed.
   Add sites in our niche that rank on our commercial keywords but host
   no ranking yet.
2. For each site: find the contact (about page, author box, contact page).
   Never guess an email address. No contact found = skip.
3. Sort each lead into a rung: network blog, business site, pure-player
   media, or author opportunity. Different email per rung.
4. Write the email. Short, personal, one concrete offer:
   - business sites: a swap, we list them in our matching ranking
   - media: a story or data they can use, never "say we are the best"
5. Write outreach/<date>.csv with: email, first_name, site, ranking_url,
   rung, personalised first line.
6. Push the CSV to the Instantly campaign through its API, key from the
   environment, never printed. Max 10 new leads a day per mailbox.
7. Every day: read new replies, classify (yes / question / no / wrong
   person), draft an answer for each. I approve before anything is sent.
