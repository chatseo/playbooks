---
name: footprint-audit
description: Audit our off-site footprint for GEO. Use when asked where we are visible, which network to pick, or before starting social or reviews.
---
1. Ask ChatSEO, word for word:
   "Who ranks top 10 on '<brand> reviews', '<brand> alternative' and
   '<brand>'? List every third-party page and what it says about us."
2. For each page: platform (review site, social, media, blog, forum),
   tone in one line, date, and whether it links to us.
3. Check which single review platform ranks first on "<brand> reviews".
   That is the one we push. Count our reviews there.
4. From geo-queries.md, list which platforms appear in the top 10 of
   our GEO queries. Those are the networks worth posting on. Max 4.
5. Write footprint.md: what exists, what is missing, 5 actions ranked
   by business value. Nothing gets posted without me.
