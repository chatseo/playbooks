---
name: geo-queries
description: Build the list of queries AI assistants search for this site. Use when asked about GEO, ChatGPT visibility, AI citations, or which prompts to track.
---
1. Read keywords.md (commercial keywords, from money-keywords).
   If it does not exist, ask ChatSEO (send_message, siteId), word for word:
   "List my commercial keyword patterns, with monthly volume."
2. For the top 10 commercial keywords, generate the GEO queries:
   - "best <keyword> <current year>"
   - "best <keyword> <current year> <country>"
   - the same two in English if the site is not English
   - "<brand> reviews", "<brand> alternative" for us and our top 3 competitors
3. Send ChatSEO, word for word, one keyword at a time:
   "Who ranks top 10 on <query>? Which of those pages are rankings,
   listicles or review pages, and does my site appear in them?"
4. Write geo-queries.md: query, the ranking pages in the top 10,
   whether we are listed, our position in the list, the domain behind it.
5. Never invent a volume or a ranking. Blank beats plausible.
