---
name: geo-watch
description: Monthly GEO check. Use on the first Monday of the month, or when asked whether we are still cited.
---
1. For each query in geo-queries.md, ask ChatSEO, word for word:
   "Who ranks top 10 on <query> today?"
   Compare to last month: new listicles, lost listicles, our position.
2. Fetch every third-party ranking we were listed in. Check we are still
   there and at which position. Flag removals and drops.
3. Flag rankings whose title still carries last year. Draft a refresh
   request to the site owner, offering to update our side of the swap.
4. Give me the 10 GEO queries to test by hand this month, in a logged-out
   ChatGPT window, and a table to note: cited yes or no, which source.
5. Write geo/<month>.md and 5 actions, ranked by business value.
