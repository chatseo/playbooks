---
name: self-rank-audit
description: Find and fix pages where we rank ourselves first. Use when asked to audit rankings, listicles or "best" pages for GEO.
---
1. List every page whose title or H1 contains "best", "top", "ranking"
   or a year, from the sitemap.
2. For each, record: who is listed 1st, whether it is us, and the page's
   clicks over the last 90 days (ask ChatSEO for the Search Console data).
3. Pages where we are 1st AND the page gets clicks: do not touch.
   List them for me with the click count. I decide.
4. Pages where we are 1st and get no clicks: rewrite the ranking on the
   merits. We may stay in the list, honestly placed, never 1st by default.
5. DIFF GATE. Before saving, list every element in the old version that is
   missing from the new one: tables, rows, links, images, schema.
   Show me. Publish nothing without my yes.
6. One page per run. This is expensive in tokens, so never batch the site.
