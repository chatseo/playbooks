---
name: swap-ranking
description: Write the ranking we owe a partner in a ranking swap. Use when a swap is agreed, or when asked to publish a "best X" page for a partner.
---
1. Input: the partner, the query they want ("best <their category>
   <city or country> <current year>"), and where it goes on our site.
2. Run page-brief on that query. Follow what the top 3 already do.
3. List 5 to 10 real players for the query, partner included, each with
   one honest line on who it suits. The partner goes 1st, as agreed.
   We never appear in a ranking of our own category.
4. Year and "best" in the title and H1. A short method section saying
   how the list was chosen. A date at the top.
5. Ship it through ship-page, diff gate included.
6. Add the page to swaps.md: partner, query, URL, date, and the URL of
   their ranking that lists us. geo-watch checks both every month.
