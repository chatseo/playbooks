Claude Chief of GEO: 6 Claude Code skills
https://chatseo.github.io/playbooks/claude-chief-of-geo/

1. Unzip at the root of your repo (it creates .claude/skills/).
2. Connect ChatSEO (Pro plan, MCP):
   claude mcp add --transport http chatseo https://api.chatseo.app/mcp
3. Open Claude Code, /model -> Opus, /mcp to log in once.
4. Ask: "run geo-queries".

Order: geo-queries -> self-rank-audit -> swap-ranking / citation-outreach -> footprint-audit -> geo-watch (monthly).
