---
description: Build a full topic cluster: $ARGUMENTS.
---

Build a full topic cluster: $ARGUMENTS. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. keyword-clusters
2. topic-clusters
3. content-brief for the pillar and each support
4. hub-pages
5. internal-linker

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
