---
description: From zero to a clustered, scored keyword plan.
---

From zero to a clustered, scored keyword plan. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. keyword-research
2. long-tail
3. search-intent
4. keyword-clusters
5. content-strategy

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
