---
description: Run a backlink campaign.
---

Run a backlink campaign. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. backlink-gap
2. link-prospector
3. outreach-writer (drafts only)
4. guest-posts
5. update seo/prospects.md with status

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
