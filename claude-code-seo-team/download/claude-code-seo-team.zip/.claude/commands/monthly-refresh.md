---
description: The monthly update cycle on existing pages.
---

The monthly update cycle on existing pages. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. refresh-plan
2. content-refresh on the top 5
3. title-meta
4. change-log skill

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
