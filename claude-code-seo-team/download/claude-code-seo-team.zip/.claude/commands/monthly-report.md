---
description: Month-end report.
---

Month-end report. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. gsc-analyst on the month
2. rank-tracker
3. seo-reporting
4. forecasting update

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
