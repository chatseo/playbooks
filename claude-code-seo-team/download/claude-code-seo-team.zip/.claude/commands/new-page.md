---
description: Plan, write, optimise and link one new page for a keyword: $ARGUMENTS.
---

Plan, write, optimise and link one new page for a keyword: $ARGUMENTS. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. Check no existing URL targets it (if one does, run /refresh-page instead)
2. serp-analysis
3. content-brief
4. longform-writer or page-writer
5. content-editor
6. schema
7. internal-linker
8. diff-gate skill

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
