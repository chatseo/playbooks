---
description: Launch a set of template pages: $ARGUMENTS.
---

Launch a set of template pages: $ARGUMENTS. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. keyword-research on the pattern
2. programmatic-seo (3 samples, then stop for review)
3. schema
4. site-architecture
5. internal-linker

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
