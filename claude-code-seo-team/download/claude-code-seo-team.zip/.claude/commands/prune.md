---
description: Find and handle dead pages.
---

Find and handle dead pages. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. content-pruning
2. redirect-map skill
3. orphan-finder
4. diff-gate skill before any deletion

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
