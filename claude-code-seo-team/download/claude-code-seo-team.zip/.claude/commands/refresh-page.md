---
description: Update one existing page: $ARGUMENTS.
---

Update one existing page: $ARGUMENTS. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. onpage-seo
2. content-refresh
3. title-meta
4. headings
5. internal-linker
6. diff-gate skill

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
