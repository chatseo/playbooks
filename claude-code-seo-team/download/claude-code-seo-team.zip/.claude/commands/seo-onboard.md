---
description: Onboard a new site: data, audit and a first plan.
---

Onboard a new site: data, audit and a first plan. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. chatseo-data skill: find the site ID
2. keyword-research
3. search-intent
4. competitor-intel
5. technical-seo
6. content-strategy: write seo/calendar.md

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
