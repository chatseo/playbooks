---
description: Diagnose and respond to a sudden drop.
---

Diagnose and respond to a sudden drop. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. traffic-drops
2. indexing on the affected pages
3. crawl-audit
4. onpage-seo on the 3 biggest losers
5. write seo/drops/<date>.md with the decision

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
