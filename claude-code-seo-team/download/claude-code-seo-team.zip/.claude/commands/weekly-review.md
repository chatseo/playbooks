---
description: The Monday review, 15 minutes.
---

The Monday review, 15 minutes. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. gsc-analyst
2. rank-tracker
3. share-of-voice
4. update seo/calendar.md with the 3 actions for the week

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
