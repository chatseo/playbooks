---
name: brief-format
description: The standard content brief structure. Use when writing or reading a brief.
---

# brief-format

Target keyword, secondary keywords, intent, existing URL (or "new"), H1, title, meta,
outline (H2s and H3s), questions to answer (from PAA), the element the top 3 lack,
internal links in and out, word range from the top 3, sources to cite, CTA.
