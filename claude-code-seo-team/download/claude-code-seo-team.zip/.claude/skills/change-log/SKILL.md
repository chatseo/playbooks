---
name: change-log
description: How to log every SEO change so results can be measured. Use after every publish.
---

# change-log

Append to seo/changes.md: date, URL, change type (new, update, title, links, schema, redirect, delete), summary, agent.
Performance is judged 4 to 8 weeks after the date logged, never earlier.
