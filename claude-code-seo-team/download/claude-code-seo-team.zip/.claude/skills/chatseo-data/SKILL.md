---
name: chatseo-data
description: How to get real SEO numbers from the ChatSEO MCP. Use whenever a task needs volumes, rankings, Search Console or a live SERP.
---

# chatseo-data

1. Call `list_sites` once and keep the site ID.
2. Ask in plain language with `send_message` (site ID + the question). Ask for the exact columns you need.
3. Poll `get_conversation_messages` until the reply is complete. Don't re-send while it's running.
4. Copy numbers exactly as returned. A missing number is "n/a", never an estimate.
5. Save the raw answer under `seo/data/<date>-<topic>.md` so other agents reuse it instead of asking again.
