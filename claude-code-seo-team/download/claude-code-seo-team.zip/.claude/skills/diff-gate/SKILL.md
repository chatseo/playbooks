---
name: diff-gate
description: Review gate before any change goes live. Use before publishing anything an agent wrote.
---

# diff-gate

Show the diff of every changed page. Check: nothing removed that ranks (compare with the page's queries), links resolve, schema validates, no invented numbers, title and meta unique.
Wait for the user's explicit yes. Then publish and log it in seo/changes.md.
