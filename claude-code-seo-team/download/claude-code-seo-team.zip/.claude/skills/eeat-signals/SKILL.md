---
name: eeat-signals
description: The checklist of trust signals. Use on YMYL pages or when bigger brands outrank the site.
---

# eeat-signals

Named author with photo, bio and credentials. First-hand experience (photos, tests, data). Sources cited inline.
Visible update date. About, contact and editorial policy pages. Reviews from third parties. Consistent business facts.
