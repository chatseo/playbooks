---
name: geo-queries
description: How to find the Google searches behind AI answers. Use for any GEO task.
---

# geo-queries

AI assistants search the web for most recommendation questions, usually with queries like "best [category] [year]", "[brand] vs [brand]", "[category] for [audience]".
For each buyer question, write the 3 likely searches, check their top 10, and target those pages: rank on them, or get listed on them.
