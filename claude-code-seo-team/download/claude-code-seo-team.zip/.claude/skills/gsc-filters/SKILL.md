---
name: gsc-filters
description: Useful Search Console filters. Use when analysing performance.
---

# gsc-filters

- Striking distance: position 8-20, impressions 100+.
- CTR problems: position 1-5, CTR below 50% of the site average for that position.
- Cannibalisation: one query, 2+ pages with impressions.
- Decay: page clicks down 30%+ over 3 months vs the 3 before.
- Dead pages: 0 clicks, under 50 impressions, 90 days.
