---
name: intent-classification
description: Rules for classifying search intent from the SERP. Use for every keyword before a page is planned.
---

# intent-classification

- Commercial: product, category, service, pricing or comparison pages hold most of the top 5.
- Informational: articles, guides, definitions, videos dominate.
- Navigational: one brand's pages dominate.
- Mixed: no type holds 6+ of the top 10. Build the type of the result at position 1 and note it.
The SERP decides. The keyword's wording does not.
