---
name: internal-link-rules
description: Internal linking rules. Use whenever adding or auditing links.
---

# internal-link-rules

- Links go inside body text, in a sentence that explains the target.
- 5+ internal links in to every page that matters, at least one from a page with traffic.
- Anchors describe the target page. Vary them. No "click here".
- Supporting pages link to their hub. Hubs link to every supporting page.
- Never link to a redirect or a 404: link to the final URL.
