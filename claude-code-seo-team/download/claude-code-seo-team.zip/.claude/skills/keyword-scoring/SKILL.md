---
name: keyword-scoring
description: Scores keyword opportunities by business value. Use when ranking a keyword list.
---

# keyword-scoring

Score = intent (commercial 3, mixed 2, informational 1) x 2
      + existing impressions (site already shows: 3, position 11-30: 2, none: 0)
      + volume band (top third 2, middle 1, bottom 0)
      - difficulty band (hard 2, medium 1, easy 0).
Sort descending. A keyword with buyers beats a keyword with readers.
