---
name: meta-description
description: Meta description rules. Use when writing any meta description.
---

# meta-description

Under 155 characters. Answer the query in the first sentence, give one reason to click in the second.
Use the words of the query (Google bolds them). No quotes (they truncate). Different for every page.
