---
name: outreach-rules
description: Rules for outreach emails. Use for every link or mention request.
---

# outreach-rules

Under 100 words. First line proves you read their page. One ask. One reason it helps their readers.
No attachments, no "I hope this finds you well". One follow-up after 5 days. The user sends, never the agent.
