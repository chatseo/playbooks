---
name: pruning-filter
description: The filter for dead pages. Use before deleting anything.
---

# pruning-filter

A page is a pruning candidate when, over 90 days: 0 clicks, under 50 impressions, and it was published more than 3 months ago.
Then: backlinks → redirect, never 404. Same intent as a better page → merge + 301. Topic you want to own → rewrite. Otherwise → delete.
