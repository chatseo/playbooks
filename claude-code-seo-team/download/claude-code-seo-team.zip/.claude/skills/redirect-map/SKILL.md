---
name: redirect-map
description: How to plan redirects without losing rankings. Use for pruning, merges and migrations.
---

# redirect-map

One row per old URL: old URL, new URL, reason. 301 to the closest equivalent page, never all to the homepage.
No chains: if A→B and B→C exist, change A→C. Update internal links to the final URL.
Keep redirects for at least a year. Check old URLs with backlinks first.
