---
name: report-format
description: The SEO report structure. Use for any client or manager report.
---

# report-format

1. Three numbers: clicks, impressions, conversions, vs last month and last year.
2. What we did (from seo/changes.md).
3. What it moved, with the evidence.
4. What's next, 3 actions, ranked.
One page. Every term explained in a line. No screenshots without a sentence saying what to see.
