---
name: schema-snippets
description: Ready JSON-LD patterns per page type. Use when adding structured data.
---

# schema-snippets

Organization (home, with sameAs to every official profile), LocalBusiness (address, hours, geo),
Product (name, image, offers, aggregateRating only if reviews are on the page),
Article (headline, author with url, datePublished, dateModified), FAQPage (only Q&As visible on the page),
BreadcrumbList (every page below level 1). Validate with Google's Rich Results Test before publishing.
