---
name: seo-folder
description: The shared seo/ folder conventions every agent follows. Use before reading or writing any SEO file.
---

# seo-folder

- One topic per file, named in kebab-case. Dated files use YYYY-MM-DD.
- Tables in Markdown, first column the URL or keyword.
- Never overwrite another agent's file: append a dated section, or write a new dated file.
- `seo/changes.md` is the log of everything published: date, URL, what changed, which agent proposed it.
- `seo/plan.md` / `seo/calendar.md` is the single source for what's next.
