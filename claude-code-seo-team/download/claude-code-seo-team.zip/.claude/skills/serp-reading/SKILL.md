---
name: serp-reading
description: How to read a SERP: page types, features, what the top 3 reward. Use before targeting any keyword.
---

# serp-reading

For the live top 10, record per result: URL, page type (product, category, article, tool, forum, video), approximate length, date, and the one thing it does best.
Then note the SERP features: AI Overview (and cited URLs), featured snippet (format), People Also Ask, local pack, video, shopping.
Conclusion in one line: the page type to build, the depth needed, and the element none of the top 3 has.
