---
name: striking-distance
description: Finds and handles keywords at positions 8 to 20. Use for quick wins.
---

# striking-distance

Filter Search Console queries at average position 8 to 20 with 100+ impressions.
Check the ranking URL is the right page for the query. Then: add the query to the H1/title if missing, answer it in the first 100 words, add 3 internal links from related pages.
Don't touch pages edited in the last 60 days.
