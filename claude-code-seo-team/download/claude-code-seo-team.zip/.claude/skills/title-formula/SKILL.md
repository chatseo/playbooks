---
name: title-formula
description: Title tag rules that lift CTR. Use when writing any title.
---

# title-formula

- Main query in the first 40 characters, total under 60.
- One concrete promise: a number, a year, a format, a result.
- Match the intent: "Best", "vs", "Price" for commercial; "How to", "Guide" for informational.
- Don't repeat the brand twice. Don't use the same title on two pages.
