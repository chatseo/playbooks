# The Claude Code SEO Team: 50 agents, 120 resources

Unzip at the root of your site's folder, then restart Claude Code.

- .claude/agents/    50 agents, 10 departments
- .claude/skills/    20 skills (shared rules)
- .claude/commands/  15 workflows (slash commands: /seo-onboard, /new-page, /weekly-review...)
- seo/templates/     15 templates
- seo/recipes.md     10 task recipes
- seo/audits/        10 audit checklists

1. Connect the ChatSEO MCP (Pro plan) so the agents get real data:
   claude mcp add --transport http chatseo https://api.chatseo.app/mcp
   then /mcp in Claude Code to log in.
2. Start with /seo-onboard.
3. Every agent writes to seo/ and reads what the others wrote. Nothing is published without your yes.

Full guide: https://chatseo.github.io/playbooks/claude-code-seo-team/
