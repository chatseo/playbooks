# Backlink profile audit

Date: 
Site: 

- [ ] Referring domains trend over 12 months
- [ ] Lost links from strong domains recovered
- [ ] Top linked pages redirect correctly if moved
- [ ] Unlinked brand mentions listed
- [ ] Spam patterns reviewed (disavow only for manual actions)
- [ ] Link gap vs top 3 competitors listed

Notes:
