# Content quality audit

Date: 
Site: 

- [ ] Each page has one clear intent
- [ ] Answers better than the current top 3
- [ ] Has one element the top 3 lack
- [ ] Facts and numbers are sourced
- [ ] Updated within the last 12 months for time-sensitive topics
- [ ] No two pages target the same query

Notes:
