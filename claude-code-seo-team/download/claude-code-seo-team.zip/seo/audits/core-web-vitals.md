# Core Web Vitals audit

Date: 
Site: 

- [ ] LCP under 2.5s on the main templates
- [ ] INP under 200ms
- [ ] CLS under 0.1
- [ ] Hero image preloaded and sized
- [ ] Fonts don't block rendering
- [ ] Third-party scripts deferred
- [ ] Images in WebP/AVIF at display size

Notes:
