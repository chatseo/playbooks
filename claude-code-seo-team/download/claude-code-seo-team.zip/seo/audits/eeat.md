# E-E-A-T audit

Date: 
Site: 

- [ ] Named author with bio on every article
- [ ] First-hand experience shown (photos, tests, data)
- [ ] About, contact and editorial pages exist
- [ ] Sources cited inline
- [ ] Update dates visible
- [ ] Third-party reviews and mentions present

Notes:
