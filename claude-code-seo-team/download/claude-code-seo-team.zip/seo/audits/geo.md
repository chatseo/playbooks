# AI visibility (GEO) audit

Date: 
Site: 

- [ ] Buyer questions listed
- [ ] Google searches behind each question checked
- [ ] Brand appears in the sources AI tools cite
- [ ] Organization schema with sameAs
- [ ] Business facts identical everywhere
- [ ] Pages give a direct 40-60 word answer under the matching heading

Notes:
