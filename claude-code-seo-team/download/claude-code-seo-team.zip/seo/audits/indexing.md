# Indexing audit

Date: 
Site: 

- [ ] Indexed pages vs sitemap pages compared
- [ ] 'Crawled, not indexed' pages reviewed one by one
- [ ] 'Discovered, not indexed' pages have internal links
- [ ] Google-selected canonical matches the declared one
- [ ] No thin or near-duplicate pages
- [ ] Every important page has 5+ internal links in

Notes:
