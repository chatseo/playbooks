# Internal linking audit

Date: 
Site: 

- [ ] No orphan pages
- [ ] Money pages within 2 clicks of the homepage
- [ ] Hubs link to every supporting page and back
- [ ] No links to redirects or 404s
- [ ] Anchors descriptive and varied
- [ ] Links inside body text, not only menus and footers

Notes:
