# Site migration audit

Date: 
Site: 

- [ ] Full URL inventory before the switch
- [ ] Redirect map for every old URL with traffic or links
- [ ] No chains, no homepage dumping
- [ ] Internal links updated to new URLs
- [ ] Canonicals, hreflang and sitemap updated
- [ ] Search Console: new property verified, sitemap submitted
- [ ] Rankings and clicks checked daily for 4 weeks

Notes:
