# On-page audit (per page)

Date: 
Site: 

- [ ] H1 contains the main query Google gives the page
- [ ] Title under 60 chars, query first
- [ ] Meta under 155 chars, answers the query
- [ ] First 100 words answer the query
- [ ] Headings form a readable outline
- [ ] Images have descriptive alt text
- [ ] 5+ contextual internal links in, 3+ out
- [ ] Schema matches the page type

Notes:
