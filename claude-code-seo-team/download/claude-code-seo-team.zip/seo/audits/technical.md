# Technical SEO audit

Date: 
Site: 

- [ ] Every important page returns 200
- [ ] No redirect chains of 2+ hops
- [ ] Canonicals point to the indexable version
- [ ] No noindex on pages that should rank
- [ ] robots.txt blocks nothing that matters
- [ ] XML sitemap lists only 200, indexable, canonical URLs
- [ ] HTTPS everywhere, no mixed content
- [ ] Mobile rendering matches desktop content
- [ ] Unique title and meta on every page
- [ ] No duplicate pages under different URLs

Notes:
