# Task recipes

Paste into Claude Code. Replace the [brackets].

## Find quick wins this week

Use the gsc-analyst agent with the striking-distance skill on [domain]. List queries at position 8 to 20 with 100+ impressions, the URL ranking, and the one change per page that could move it. Top 10 only.

## Fix low CTR pages

Use the title-meta agent on [domain]. Find pages with 500+ impressions and CTR below average for their position, and write 2 title options and a meta description for each. Check the position first.

## Write one page end to end

Run /new-page "[keyword]" on [domain]. Stop at the diff-gate and show me the diff before anything is published.

## Find and fix cannibalisation

Use the gsc-analyst agent on [domain]: find queries where 2+ of my pages get impressions. For each, pick the page to keep and propose merge, redirect or re-target for the others.

## Clean dead pages

Run /prune on [domain]. Show me the verdict table before any deletion. Never delete a page that has backlinks: redirect it.

## Build a topic cluster

Run /cluster-build "[topic]" on [domain]. Start with the cluster map, then briefs. Don't write any article before I approve the map.

## Steal a featured snippet

Use the serp-features agent on [domain]: find keywords where I rank top 5 and someone else holds the snippet. Write the replacement block in their format, answering better.

## Check if ChatGPT recommends us

Run /geo-push on [domain] for these buyer questions: [question 1], [question 2], [question 3]. Tell me which sources get cited and which don't mention us.

## Diagnose a traffic drop

Run /traffic-drop on [domain]. Clicks fell around [date]. Find the cause before suggesting any change.

## Monthly client report

Run /monthly-report on [domain] for [month]. One page, written for a client who isn't an SEO.
