# SEO audit: [site] ([date])

## Summary (3 lines)

| Issue | URLs affected | Clicks at stake | Fix | Effort | Owner |
|---|---|---|---|---|---|
