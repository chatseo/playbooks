# Brief: [keyword]

- Target keyword:
- Secondary keywords:
- Intent:
- Existing URL (or new):
- H1:
- Title (<60):
- Meta (<155):
- Word range (from top 3):

## Outline
- H2:
  - H3:

## Questions to answer (PAA)
-

## The element the top 3 lack

## Internal links
- In from:
- Out to:

## Sources
