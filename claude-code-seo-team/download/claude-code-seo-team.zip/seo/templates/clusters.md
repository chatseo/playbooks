| Cluster | Keywords | Total volume | Target URL | Status |
|---|---|---|---|---|
