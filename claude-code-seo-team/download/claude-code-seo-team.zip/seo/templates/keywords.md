| Pattern | Keyword | Volume | Difficulty | Intent | Top-3 page type | Current position | Target URL |
|---|---|---|---|---|---|---|---|
