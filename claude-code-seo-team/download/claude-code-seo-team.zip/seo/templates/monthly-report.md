# SEO report: [month]

| | This month | Last month | Last year |
|---|---|---|---|
| Clicks | | | |
| Impressions | | | |
| Conversions | | | |

## What we did

## What it moved

## What's next
1.
2.
3.
