Subject: [their page title] + one idea

Hi [name],

[One line proving you read the page.]

[The ask, in one sentence.] [Why it helps their readers.]

[Link]

[Your name]

---
Follow-up (day 5): Hi [name], just bumping this in case it got buried. [One line.]
