| Date | URL | What changed | Queries before | Check on (date + 6 weeks) | Result |
|---|---|---|---|---|---|
