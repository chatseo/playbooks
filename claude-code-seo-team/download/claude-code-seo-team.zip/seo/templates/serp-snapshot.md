# SERP: [keyword] ([date])

| Pos | URL | Page type | Length | Date | Best thing |
|---|---|---|---|---|---|

Features: AI Overview / snippet / PAA / local / video

Entry ticket:
