# The Complete Claude SEO Team: 20 Claude Code agents

Unzip into your site's repo so the files land in .claude/agents/, then restart Claude Code.

1. Connect the ChatSEO MCP (Pro plan) so the agents get real data:
   claude mcp add --transport http chatseo https://api.chatseo.app/mcp
   then /mcp in Claude Code to log in.
2. Call an agent by name: "Use the keyword-researcher agent on example.com".
3. Run order: Research. Audit. Write. Optimise. Link. Track. Measure. Rank.
   Every agent writes to seo/ and reads what the others wrote.

Full guide: https://chatseo.github.io/playbooks/claude-seo-team-20-agents/
