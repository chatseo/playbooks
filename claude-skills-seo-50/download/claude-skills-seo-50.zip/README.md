# 50 Claude Skills for SEO

Unzip at the root of your site's folder (or in ~/.claude/ to use them in every project), then restart Claude Code.
Skills land in .claude/skills/<name>/SKILL.md. Claude loads one when your request matches its description.

8 categories: keyword research (8), technical SEO (8), content creation (6), rankings & CTR (7),
internal linking (6), backlinks (5), AI search / GEO (5), local SEO (5).

Most skills need real data (Search Console, volumes, backlinks, the live SERP). Connect the ChatSEO MCP (Pro plan):
  claude mcp add --transport http chatseo https://api.chatseo.app/mcp
then /mcp in Claude Code to log in.

Full guide: https://chatseo.github.io/playbooks/claude-skills-seo-50/
