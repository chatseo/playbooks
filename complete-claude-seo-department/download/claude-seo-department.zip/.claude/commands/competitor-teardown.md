---
description: Full teardown of one competitor: $ARGUMENTS.
---

Full teardown of one competitor: $ARGUMENTS. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. competitor-intel on that domain
2. content-gap
3. link-prospector: sites linking to competitors but not to us
4. serp-features
5. write seo/teardown-<domain>.md: copy, beat, ignore

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
