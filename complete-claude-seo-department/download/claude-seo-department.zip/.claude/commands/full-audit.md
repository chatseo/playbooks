---
description: Full SEO audit across technical, on-page, links and content.
---

Full SEO audit across technical, on-page, links and content. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. technical-seo
2. crawl-audit
3. indexing
4. core-web-vitals
5. orphan-finder
6. cannibalisation-finder
7. sitemap-robots
8. link-audit
9. eeat-review on the 5 top pages
10. write seo/audit-summary.md ranked by clicks at stake

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
