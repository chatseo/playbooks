---
description: Get named in AI answers for the main buyer questions.
---

Get named in AI answers for the main buyer questions. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. geo-strategy
2. llm-citations
3. ai-overviews
4. entity-seo
5. digital-pr: brand mentions on the sites AI answers cite

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
