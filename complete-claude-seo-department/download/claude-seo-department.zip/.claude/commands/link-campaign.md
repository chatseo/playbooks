---
description: Run a backlink campaign.
---

Run a backlink campaign. Run these one at a time, in order. Each reads what the previous one wrote in `seo/`.

1. link-prospector: sites linking to competitors but not to us, scored by relevance
2. outreach-writer (drafts only)
3. digital-pr (pr-angles skill)
4. update seo/prospects.md with status

Use the ChatSEO MCP for every number. Never invent a volume or a ranking. Publish nothing without my yes.
