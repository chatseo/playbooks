---
name: ai-answer-format
description: How to write passages that AI Overviews and LLMs quote. Use when optimising for GEO or AI Overviews.
---

# ai-answer-format

Answer the question in the first 40 to 60 words under the heading that asks it.
Use a definition, a number, a list or a table: the formats that get lifted.
Name the source of every number. State it once, plainly, with no hedging.
One idea per paragraph. Update the date when the facts change. Pages that are cited are usually also ranking top 10: GEO starts with SEO.
