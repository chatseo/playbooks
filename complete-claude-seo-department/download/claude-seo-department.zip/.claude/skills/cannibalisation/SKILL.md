---
name: cannibalisation
description: How to tell real keyword cannibalisation from harmless overlap. Use before merging or re-targeting pages.
---

# cannibalisation

It is cannibalisation only when all three hold:
1. Two or more URLs get impressions for the same query in the same 90 days.
2. They serve the same intent (two product pages, two guides on the same question). A guide and a product page on one query is normal.
3. Rankings or clicks swing between them, or neither reaches the top 5.
Fix: keep the URL with more clicks and links. Merge the content of the others into it and 301 them, or re-target them to a different query and remove the shared one from their title and H1.
