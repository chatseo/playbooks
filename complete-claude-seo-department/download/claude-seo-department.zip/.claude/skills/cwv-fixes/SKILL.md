---
name: cwv-fixes
description: The usual fixes for each Core Web Vitals metric. Use when a template fails LCP, INP or CLS.
---

# cwv-fixes

LCP (target under 2.5s): serve the hero image in WebP/AVIF at its displayed size, preload it, never lazy-load it, cut render-blocking CSS/JS, use a CDN.
INP (target under 200ms): split long JavaScript tasks, defer third-party scripts (chat widgets, tag managers), remove unused JS.
CLS (target under 0.1): set width and height on every image and embed, reserve space for ads and banners, preload fonts with font-display: swap.
Fix per template, not per URL: one template fix repairs hundreds of pages.
