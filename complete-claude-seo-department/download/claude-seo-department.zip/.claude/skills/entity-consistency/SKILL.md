---
name: entity-consistency
description: How to make Google and LLMs understand the brand as one entity. Use for brand, about and GEO work.
---

# entity-consistency

Same name, same one-sentence description, same logo everywhere: site, Google Business Profile, LinkedIn, Crunchbase, Wikidata if eligible, directories.
Organization schema on the homepage with sameAs links to every official profile.
An About page that states who, what, since when, for whom, with founders named.
Third-party mentions that repeat the same description are what make an LLM state it as fact.
