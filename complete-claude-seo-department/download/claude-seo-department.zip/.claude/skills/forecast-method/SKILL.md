---
name: forecast-method
description: How to forecast SEO traffic without inventing numbers. Use when projecting clicks from a plan.
---

# forecast-method

Forecast = target keyword volume x the CTR of the target position x share of keywords you realistically reach.
Use CTR by position from the site's own Search Console when it exists; otherwise a public CTR curve, named.
Give three cases (low, mid, high) with the assumption behind each. Time to rank: 3 to 6 months for an established site, 6 to 12 for a young one.
Never present a forecast without its assumptions.
