---
name: heading-rules
description: Heading structure rules. Use when writing or restructuring a page.
---

# heading-rules

One H1 per page, close to the title, containing the main query.
H2s are the questions or steps a reader scans for; each one could be a search query on its own.
H3s only under an H2, never to style text. No skipped levels.
The first sentence after each H2 answers it directly: that is the sentence featured snippets and AI answers lift.
