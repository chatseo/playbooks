---
name: image-rules
description: Image SEO rules. Use when adding or auditing images.
---

# image-rules

- File name describes the image in words: red-trail-running-shoe.webp, not IMG_2231.jpg.
- Alt text says what the image shows, in one sentence, with the keyword only if it fits naturally. Decorative images get alt="".
- WebP or AVIF, resized to the displayed width, under 150 KB where possible.
- width and height attributes always set. Lazy-load everything below the fold, never the first image.
- Original photos beat stock: they are what image search and AI answers pick.
