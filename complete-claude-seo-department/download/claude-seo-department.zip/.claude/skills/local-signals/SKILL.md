---
name: local-signals
description: The local ranking signals and how to check them. Use for any local business.
---

# local-signals

Google Business Profile: primary category matches the main search, secondary categories added, hours and photos current, a post at least monthly, every review answered.
NAP: business name, address and phone identical on the site footer, the profile and the top directories.
Reviews: steady flow beats a burst. Ask after every job. Reply to every review, good or bad.
Location pages: one per city served, with local proof (jobs done there, photos, local reviews), not a template with the city swapped.
