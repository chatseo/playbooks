---
name: migration-checklist
description: The checks before and after a site migration. Use for any domain, CMS, URL or design change.
---

# migration-checklist

Before: crawl the old site and save it. Export every URL with clicks (12 months) and with backlinks. Build the redirect map. Copy titles, H1s, canonicals and structured data to the new templates. Keep the old XML sitemap.
Launch day: 301s live, robots.txt allows crawling, noindex removed from staging templates, new sitemap submitted, old sitemap kept submitted for 4 weeks.
After: daily clicks and indexed pages for 4 weeks, 404 report weekly, redirect chains removed. A 10 to 20 % dip for 2 to 4 weeks is normal. A drop that keeps going is a bug: find the template.
