---
name: pr-angles
description: How to find a story journalists will link to. Use for digital PR.
---

# pr-angles

The angles that earn links: original data (a survey, your own usage numbers), a ranking or index, a strong opinion backed by a number, a reaction to news within 24 hours, a free tool.
Check the angle: would a journalist write the headline without mentioning your brand? If not, it's an ad.
One pitch per angle, 120 words, the data point in the first line, the asset linked, no attachments.
