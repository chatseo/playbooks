---
name: programmatic-quality
description: The quality bar for programmatic pages. Use before generating pages at scale.
---

# programmatic-quality

Each page must hold data the other pages don't: real numbers, real listings, real comparisons. A city name swapped into the same text is a doorway page.
Ship 3 samples, review them by hand, then 20, check they index, then the rest.
Every page reachable within 3 clicks and linked from a hub. Noindex any page with fewer than [N] data points.
Watch 'crawled, not indexed' in Search Console: above 30 % on the batch means the template is too thin.
