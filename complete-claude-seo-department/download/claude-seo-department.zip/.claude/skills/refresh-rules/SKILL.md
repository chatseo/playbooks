---
name: refresh-rules
description: When and how to refresh an existing page. Use before updating content.
---

# refresh-rules

Refresh when clicks fell more than 20 % over 90 days versus the 90 before, or the top 3 changed format, or facts on the page are out of date.
Keep the URL. Keep the sections that earn queries (check Search Console per page first). Add what the new top 3 cover that you don't. Update numbers, dates, screenshots.
Change the published date only if the content really changed. Don't touch a page edited in the last 60 days.
