---
name: roadmap-priority
description: How to order SEO work. Use when building a roadmap or choosing this week's tasks.
---

# roadmap-priority

Order:
1. Anything that stops pages being crawled or indexed.
2. Pages at positions 4 to 20 on queries with buyers (fastest clicks).
3. Cannibalisation and decaying pages.
4. New pages for the clusters with the highest value.
5. Links and PR to the pages that are close to page 1.
Score = clicks at stake / effort in days. Ties go to the one that unblocks other work.
