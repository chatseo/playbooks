---
name: robots-sitemap
description: Rules for robots.txt, XML sitemaps, noindex and canonicals. Use before changing any of them.
---

# robots-sitemap

- robots.txt blocks crawling, not indexing. To remove a page from Google, use noindex and let it be crawled.
- Never block CSS or JS. Never block a URL that earns clicks.
- Sitemaps list only canonical, indexable, 200 URLs. No redirects, no 404s, no noindex.
- One canonical per page, absolute URL, pointing to itself unless it is a true duplicate.
- Faceted and filter URLs: noindex or canonical to the category, never both with a robots block.
