---
name: toxic-links
description: How to judge a backlink as harmless, weak or harmful. Use for backlink audits.
---

# toxic-links

Most low-quality links are ignored by Google, not counted against you. Do nothing about them.
Act only on: paid links you bought, link networks or PBNs, exact-match anchor spam pointing at money pages, or a manual action in Search Console.
For those: ask for removal first, disavow only what remains, at domain level.
Never disavow because a tool's toxicity score says so.
