# The Complete Claude SEO Department: 48 agents, 140 resources

Unzip at the root of your site's folder, then restart Claude Code.

- .claude/agents/    48 agents, 6 departments
- .claude/skills/    35 skills (shared rules)
- .claude/commands/  15 workflows (slash commands: /seo-onboard, /new-page, /weekly-review...)
- seo/prompts.md     32 prompts (also work in any Claude chat)
- seo/playbooks/     10 playbooks (step-by-step plans that chain the rest)

1. Connect the ChatSEO MCP (Pro plan) so the agents get real data:
   claude mcp add --transport http chatseo https://api.chatseo.app/mcp
   then /mcp in Claude Code to log in.
2. Start with /seo-onboard.
3. Every agent writes to seo/ and reads what the others wrote. Nothing is published without your yes.

Full guide: https://chatseo.github.io/playbooks/complete-claude-seo-department/
