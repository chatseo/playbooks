# Onboard an agency client in one week

**For:** Agencies and freelancers starting a new SEO client.

## Day 1

- [ ] Access: Search Console, analytics, CMS, the ChatSEO MCP on the client site.
- [ ] /seo-onboard and /competitor-teardown on their 2 main competitors.

## Day 2-3

- [ ] /full-audit. SEO Reporter turns it into a client-readable summary.

## Day 4-5

- [ ] SEO Roadmap Planner: the 90-day plan.
- [ ] Forecasting Agent: three cases with assumptions, never a promise.

## Every month

- [ ] /monthly-report. One page: what moved, why, what's next.

**Done when:** The client has a baseline, a 90-day plan and knows what the first report will show.
