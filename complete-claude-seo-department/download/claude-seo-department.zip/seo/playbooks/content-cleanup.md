# Prune and refresh a bloated blog

**For:** Blogs with hundreds of posts and most traffic on a few.

## Sort

- [ ] Content Pruning Agent: every post into keep, refresh, merge, redirect, delete (pruning-filter skill).
- [ ] Cannibalisation Finder: merge the posts that compete.

## Act

- [ ] Redirect map for every merged or deleted URL that has backlinks.
- [ ] Content Refresher on the 10 'refresh' posts with the most impressions.

## Re-link

- [ ] Orphan Page Finder, then Internal Linker on what's left.

**Done when:** Fewer pages, more clicks per page, no orphan left.
