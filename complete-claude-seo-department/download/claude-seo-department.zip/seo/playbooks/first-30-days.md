# Your first 30 days on a site

**For:** Any site you just took over: your own, a new client, a new job.

## Week 1

- [ ] Connect Search Console and the ChatSEO MCP.
- [ ] Run /seo-onboard. Read seo/calendar.md.
- [ ] Run /full-audit. Fix only what blocks indexing on pages with clicks.

## Week 2

- [ ] Ask the Search Console Analyst for striking-distance queries (prompt 1).
- [ ] Run /refresh-page on the 3 pages closest to page 1.

## Week 3

- [ ] Run /keyword-plan. Cut every cluster without buyer intent.
- [ ] Run /new-page on the best remaining opportunity.

## Week 4

- [ ] Run /weekly-review. Run the SEO Roadmap Planner to write seo/roadmap.md for the quarter.

**Done when:** seo/roadmap.md exists, indexing blockers are fixed, 3 pages refreshed, 1 new page live.
