# Get cited by ChatGPT and AI Overviews

**For:** Brands that want to be named in AI answers in their category.

## Baseline

- [ ] Prompt 'Am I cited by AI': 20 buyer questions, record who is named today.
- [ ] LLM Citation Tracker writes seo/geo-tracker.md.

## Make the brand one entity

- [ ] Entity Builder: same name and description everywhere, Organization schema with sameAs.
- [ ] About page that states who, what, for whom.

## Become the source

- [ ] GEO Strategist: the 10 questions to own.
- [ ] AI Overview Optimiser: answer each in 40-60 words on your best page.
- [ ] Digital PR Agent: get named on the pages the AI answers already cite.

## Re-check

- [ ] Re-run the 20 questions every 30 days. Compare with the baseline.

**Done when:** Named in more answers at day 60 than at day 0, measured on the same 20 questions.
