# Rank a local business in the map pack

**For:** Shops, trades, clinics, agencies with a city.

## Profile

- [ ] Local SEO Agent: compare your Google Business Profile with the map pack top 3.
- [ ] Fix categories, hours, photos. Start weekly posts.

## Reviews

- [ ] Ask every customer. Reply to every review within 48 hours.

## Site

- [ ] NAP identical everywhere (local-signals skill).
- [ ] One location page per city served, with real local proof.
- [ ] LocalBusiness schema on each.

## Links

- [ ] Local directories, suppliers, local press (Digital PR Agent).

**Done when:** In the map pack top 3 for the main service + city query.
