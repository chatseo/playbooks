# The monthly SEO routine

**For:** Any site with SEO already running.

## Every Monday

- [ ] /weekly-review: 3 actions for the week, nothing more.

## Week 1 of the month

- [ ] /monthly-report. /monthly-refresh on the 5 pages that lost the most.

## Week 2-3

- [ ] /new-page on the next 2 opportunities in seo/roadmap.md.
- [ ] /link-campaign towards pages at positions 8 to 20.

## Week 4

- [ ] /geo-push re-check. Update seo/roadmap.md.

**Done when:** Every month: 5 pages refreshed, 2 new pages, a report, and an updated roadmap.
