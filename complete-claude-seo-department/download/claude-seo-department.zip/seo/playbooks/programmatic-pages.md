# Launch programmatic pages safely

**For:** Sites with data that can fill many pages: listings, locations, integrations, comparisons.

## Prove the pattern

- [ ] Keyword Research Agent on the pattern: is there volume across the variations?
- [ ] Programmatic SEO Agent: 3 samples. Review by hand.

## Ship in batches

- [ ] 20 pages. Check they index within 3 weeks.
- [ ] Then the rest, linked from hubs (Site Architect, Internal Linker).

## Watch

- [ ] 'Crawled, not indexed' above 30 % = the template is too thin: add data, not words.

**Done when:** Most of the batch indexed and earning impressions within 8 weeks.
