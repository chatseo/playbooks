# Rank a new page from zero

**For:** One keyword you don't rank for yet.

## Before writing

- [ ] Check no existing page targets it (Cannibalisation Finder).
- [ ] SERP Feature Analyst: page type, depth, features to win.
- [ ] Content Brief Writer: the brief.

## Writing

- [ ] Long-Form Writer or Landing Page Writer from the brief.
- [ ] Content Editor: facts, fluff, structure.
- [ ] Title & Meta Writer, Heading Structurer, Schema Markup Engineer.

## After publishing

- [ ] Internal Linker: 5 links from pages with traffic.
- [ ] Request indexing in Search Console.
- [ ] Rank Tracker: check at 2, 4 and 8 weeks. At 8 weeks on page 2, send it to the Link Prospector.

**Done when:** Indexed within 2 weeks, on page 1 or with a link plan within 8.
