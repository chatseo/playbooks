# Recover from a traffic drop

**For:** Clicks fell more than 20 % and you don't know why.

## Diagnose (day 1)

- [ ] Run /traffic-drop.
- [ ] Answer three questions: sitewide or a few pages? Update date, site change or season? Lost rankings or lost CTR?

## Fix (week 1-2)

- [ ] Technical cause: Indexing Doctor and Crawl Error Fixer on the affected template.
- [ ] Rankings lost to better pages: Content Refresher on the top 5 losers.
- [ ] CTR lost to an AI Overview: AI Overview Optimiser on those queries.

## Watch (week 3-8)

- [ ] Weekly /weekly-review. Don't touch a fixed page again for 60 days.

**Done when:** The cause is named in seo/drops/, the fix is shipped, clicks are tracked weekly.
