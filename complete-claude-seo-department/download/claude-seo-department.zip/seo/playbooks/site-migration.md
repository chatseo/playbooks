# Migrate a site without losing traffic

**For:** Domain change, new CMS, new URL structure or redesign.

## 4 weeks before

- [ ] Site Migration Guard: every URL with clicks or backlinks.
- [ ] Redirect map (prompt 'Migration redirect map'). No URL with clicks left without a destination.

## On staging

- [ ] Check titles, H1s, canonicals, schema, internal links match the old site.
- [ ] Sitemap & Robots Agent: remove staging noindex and blocks before launch.

## Launch day

- [ ] 301s live, new sitemap submitted, old sitemap kept 4 weeks.

## 4 weeks after

- [ ] Daily clicks and indexed pages. 404 report weekly. Fix any template that keeps losing.

**Done when:** Clicks back to the pre-migration level within 4 to 8 weeks.
