# 32 prompts

Paste into Claude (claude.ai or Claude Code). Replace the [brackets].

## 1. Find quick wins this week

Use the gsc-analyst agent with the striking-distance skill on [domain]. List queries at position 8 to 20 with 100+ impressions, the URL ranking, and the one change per page that could move it. Top 10 only.

## 2. Fix low CTR pages

Use the title-meta agent on [domain]. Find pages with 500+ impressions and CTR below average for their position, and write 2 title options and a meta description for each. Check the position first.

## 3. Write one page end to end

Run /new-page "[keyword]" on [domain]. Stop at the diff-gate and show me the diff before anything is published.

## 4. Find and fix cannibalisation

Use the gsc-analyst agent on [domain]: find queries where 2+ of my pages get impressions. For each, pick the page to keep and propose merge, redirect or re-target for the others.

## 5. Clean dead pages

Run /prune on [domain]. Show me the verdict table before any deletion. Never delete a page that has backlinks: redirect it.

## 6. Build a topic cluster

Run /cluster-build "[topic]" on [domain]. Start with the cluster map, then briefs. Don't write any article before I approve the map.

## 7. Steal a featured snippet

Use the serp-features agent on [domain]: find keywords where I rank top 5 and someone else holds the snippet. Write the replacement block in their format, answering better.

## 8. Check if ChatGPT recommends us

Run /geo-push on [domain] for these buyer questions: [question 1], [question 2], [question 3]. Tell me which sources get cited and which don't mention us.

## 9. Diagnose a traffic drop

Run /traffic-drop on [domain]. Clicks fell around [date]. Find the cause before suggesting any change.

## 10. Monthly client report

Run /monthly-report on [domain] for [month]. One page, written for a client who isn't an SEO.

## 11. Keyword research from a seed

Act as my Keyword Research Agent. My site: [domain], it sells [offer] to [audience]. Seed keyword: [seed]. Using only the keyword data I paste below (or the ChatSEO MCP if connected), give me max 30 keywords in a table: keyword, volume, difficulty, intent, already ranking? Drop anything with no volume in the data. End with the one pillar keyword. Never estimate a volume.

[paste keyword export]

## 12. Read the intent of a SERP

Here are the top 10 results for "[keyword]" (URL, title, page type). Classify the intent (commercial, informational, navigational, mixed) from the page types, not from the wording of the keyword. Then tell me the page type I should build and the one thing none of the top 3 has.

[paste top 10]

## 13. Cluster a keyword list

Group these keywords into clusters, one page per cluster. Two keywords belong together when they would be answered by the same page for the same intent. Output: cluster name, keywords, total volume, existing URL that should own it or "new page". Flag clusters that two of my pages already compete for.

[paste keywords + my URLs]

## 14. Competitor content gap

Act as my Content Gap Analyst. Below are the pages and top keywords of [competitor 1], [competitor 2] and my site [domain]. List the topics they both rank for and I don't, with total volume. Ignore topics with no buyer intent for [offer]. Top 15, sorted by value, then the one page I should build first.

[paste exports]

## 15. Technical audit triage

Act as my Technical SEO Auditor. Below is a crawl export of [domain]. Group issues by template, not by URL. For each: what's wrong, how many URLs, how many of those URLs earn clicks (from the Search Console data below), the fix. Sort by clicks at stake. Ignore issues on pages with zero impressions.

[paste crawl + GSC pages]

## 16. Why isn't this page indexed

Act as my Indexing Doctor. URL: [url]. Search Console status: [status, e.g. Crawled - currently not indexed]. Here is the page's HTML head, its word count, the number of internal links pointing to it and its canonical. Give me the most likely cause from this evidence only, the fix, and how I'll know it worked.

[paste]

## 17. Robots.txt review

Act as my Sitemap & Robots Agent. Here is my robots.txt and the list of my URLs that earn clicks. Tell me if any line blocks a URL that earns clicks, any CSS/JS, or a whole section by mistake. Then give me the corrected file, with a one-line comment above each change.

[paste robots.txt + URL list]

## 18. Schema for a page

Act as my Schema Markup Engineer. Page type: [product / article / local business / FAQ]. Here is the visible content of the page. Write the JSON-LD, using only facts visible on the page. No aggregateRating unless reviews are on the page. No FAQ schema for questions that aren't on the page. Then tell me how to validate it.

[paste page content]

## 19. Migration redirect map

Act as my Site Migration Guard. Old URLs (with clicks and backlinks) and new URLs are below. Map every old URL to the closest new one, never to the homepage by default. Flag old URLs with clicks and no good match, and any redirect chains. Output a CSV: old, new, clicks, backlinks, note.

[paste both lists]

## 20. Content brief

Act as my Content Brief Writer. Keyword: [keyword]. Here are the top 3 ranking pages (headings and word counts) and the People Also Ask questions. Write the brief: H1, title (under 60 chars), meta (under 155), H2/H3 outline, questions to answer, the element the top 3 lack, word range, 3 internal links to add from my site, CTA.

[paste SERP data + my sitemap]

## 21. Long-form article from a brief

Act as my Long-Form Writer. Write the article from this brief. Answer each H2 in its first sentence. Use only facts in the brief or the sources I paste; where a number is missing, write [NUMBER NEEDED] instead of inventing one. No intro about "in today's world". Short paragraphs. End on one clear next step.

[paste brief + sources]

## 22. Landing page that converts and ranks

Act as my Landing Page Writer. Offer: [offer]. Target keyword: [keyword]. Audience: [who]. Proof I have: [numbers, testimonials, logos]. Write the page: H1 with the keyword, a sub-line with the outcome, 3 benefit sections, proof, objections answered, FAQ from real questions, one CTA repeated. Use only the proof I gave you.

## 23. Edit for facts and fluff

Act as my Content Editor. Here is a draft. 1. Highlight every claim or number without a source. 2. Cut every sentence that says nothing. 3. Check each H2 is answered in its first sentence. 4. Check the keyword is in the title, H1 and first 100 words. Return the edited draft and a list of what you changed.

[paste draft]

## 24. Refresh a decaying page

Act as my Content Refresher. URL: [url]. Below: its Search Console queries for the last 90 days vs the 90 before, its current content, and the current top 3 for its main query. Tell me which sections still earn queries (keep), what the top 3 cover that I don't (add), and what's outdated (update). Then write the new sections only.

[paste]

## 25. Titles and metas in bulk

Act as my Title & Meta Writer. Below: URL, main query, position, impressions, CTR for my top pages. For every page with CTR below the average for its position, write 2 title options (under 60 chars, query in the first 40) and one meta (under 155). Don't touch pages already above average.

[paste GSC pages]

## 26. E-E-A-T review

Act as my E-E-A-T Reviewer. Here is a page from [domain] on [topic]. List what a reader would need to trust it: author, experience shown, sources, date, contact. For each missing signal, write the exact element to add (the author bio text, the source line, the photo caption). Sort by impact.

[paste page]

## 27. Internal links for a new page

Act as my Internal Linker. New page: [url] targeting [keyword]. Below is the list of my pages with their titles and traffic. Pick the 5 most relevant pages with traffic to link from, and write the exact sentence and anchor to add in each. Anchors describe the target, all different.

[paste pages]

## 28. Outreach email

Act as my Outreach Writer. Target site: [site], the page of theirs I want a link on: [url], my page: [url]. Write a 90-word email: why their readers need my page (one specific reason tied to their article), what exactly I suggest, no flattery, no "I hope this finds you well". Subject line under 6 words. One follow-up, 40 words.

## 29. Am I cited by AI

Act as my LLM Citation Tracker. My brand: [brand], my category: [category]. Write the 20 questions a buyer would ask ChatGPT or Perplexity before buying in this category (best X, X vs Y, X for [use case], X alternatives). I'll run them and paste the answers back; then list for each: am I named, who is named, which sources are cited.

## 30. Win an AI Overview

Act as my AI Overview Optimiser. Query: [query]. Here is the current AI Overview text and the pages it cites, and my page. Rewrite the section of my page that answers this query: answer in 40 to 60 words under a heading that asks the question, then the supporting detail as a list or table, with the source of each number.

[paste]

## 31. Explain a traffic drop

Act as my Traffic Drop Detective. Below: daily clicks for 6 months, the pages and queries that lost most in the last 28 days vs the 28 before, and the dates of any site changes I made. Tell me: sitewide or a few pages? Matches a Google update date, a change of mine, or seasonality? The most likely cause from the evidence, and what to check first. No guessing beyond the data.

[paste]

## 32. 90-day SEO roadmap

Act as my SEO Roadmap Planner. Below are my audit findings, keyword plan, and Search Console top pages and queries. Build a 90-day plan in 3 months: indexing blockers first, then pages at positions 4 to 20 with buyer intent, then refreshes, then new pages, then links. For each action: who does it, the outcome expected, done-when. Then name 3 things we deliberately won't do this quarter.

[paste]
