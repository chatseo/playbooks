# Node map

## 1. Intake & Data (01-intake-and-data.json, runs Monday, via the orchestrator)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Search Console pull | GSC pull (last 28 days), GSC pull (previous 28 days) | Search Console API |  |
| Sitemap read | Sitemap read | live page / sitemap |  |
| Page inventory | Page inventory |  |  |
| Owner assignment | Owner assignment, Save page inventory |  | sheet: pages |

## 2. Opportunity Scoring (02-opportunity-scoring.json, runs Monday, after module 1)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Positions 8-15 | Read pages, Read open opportunities, Positions 8-15 | sheet: pages, sheet: opportunities |  |
| Low-CTR pages | Low-CTR pages |  |  |
| Decay detector | Decay detector |  |  |
| Priority score | Priority score, Save opportunities |  | sheet: opportunities |

## 3. Content Planning (03-content-planning.json, runs Monday, after module 2)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Query clusters | Read opportunities, Read pages for links, Query clusters | sheet: opportunities, sheet: pages |  |
| Content brief | Read the live page, Prep brief prompts, Claude: content brief, Parse brief | live page / sitemap, Claude API |  |
| Internal link map | Internal link map |  |  |
| Writer queue | Shape brief rows, Save briefs, Mark opportunities briefed, Update opportunities |  | sheet: briefs, sheet: opportunities |

## 4. Content Production (04-content-production.json, runs Monday, after module 3)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Title & meta rewrite | Read briefs, Ready briefs, Read the live page, Prep title prompts, Claude: title & meta, Parse title & meta | sheet: briefs, live page / sitemap, Claude API |  |
| Section drafts | Prep section prompts, Claude: section drafts, Parse sections | Claude API |  |
| Schema check | Schema check |  |  |
| Editor review | Shape draft rows, Save drafts, Tell the editor |  | sheet: drafts, Slack |

## 5. Approval & Publishing (05-approval-and-publishing.json, runs daily, once per draft (the orchestrator starts one run per draft))

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Approval checklist | Mark awaiting approval, Update draft status, Approval checklist, Ask for approval, Wait for the decision, Approved? | your Approve / Reject click | sheet: drafts, Slack |
| CMS update | Find the WordPress post, Match the post, CMS update | WordPress REST | WordPress REST |
| Live page QA | Re-read the live page, Live page QA | live page / sitemap |  |
| Index status check | Index status check, QA verdict, QA passed? | URL Inspection API |  |
| Outcome | Log the publish, Save to publish log, Status: published, Log the exception, Save exception, Exception alert, Status: exception, Status: rejected, Update draft status (final) |  | sheet: publish_log, sheet: exceptions, sheet: drafts, Slack |

## 6. Tracking (06-tracking.json, runs daily, via the orchestrator)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| 14-day recheck | Read publish log, Read past rechecks, Due rechecks, GSC before, GSC after | sheet: publish_log, sheet: tracking, Search Console API |  |
| CTR change | CTR change |  |  |
| AI citation check | AI citation check, Cited?, Save recheck | Perplexity API (optional) | sheet: tracking |
| Drop alerts | Dropped?, Drop alert |  | Slack |

## 7. Reporting & Improvement (07-reporting-and-improvement.json, runs Friday, via the orchestrator)

| Step | n8n nodes | Reads | Writes |
|---|---|---|---|
| Weekly digest | Read rechecks, Read publish log, Read exceptions, Read pages, Weekly digest | sheet: tracking, sheet: publish_log, sheet: exceptions, sheet: pages |  |
| Wins & losses log | Wins & losses log |  |  |
| Missing-data report | Missing-data report, Prep process prompt, Claude: one process change, Parse proposal | Claude API |  |
| Approved process change | Send digest + proposal, Wait for the decision, Approved?, Log the change, Save to changelog | your Approve / Reject click | Slack, sheet: changelog |

## 0. Central Orchestration (00-orchestrator.json)

Monday 07:00 runs 1 → 2 → 3 → 4. Every day 09:00 starts one run of 5 per draft in needs_review, runs 6, and requeues drafts whose exception was set to retry. Friday 16:00 runs 7.

## 8. Exceptions (08-exceptions.json)

Error Trigger → exceptions tab (status open) → Slack. Set it as the Error workflow of the 8 others.
