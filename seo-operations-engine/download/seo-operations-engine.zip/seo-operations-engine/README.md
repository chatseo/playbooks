# The Ultimate SEO Operations Engine (n8n)

7 modules, 9 importable workflows, run by one orchestrator, with a Google Sheet as memory.
Full guide with the node map and every prompt: https://chatseo.github.io/playbooks/seo-operations-engine/

## What's in this zip
- workflows/  9 n8n workflow files (00 orchestrator, 01-07 modules, 08 error workflow)
- sheets-template/  one CSV per tab: create a Google Sheet with these 8 tabs and header rows
- config.example.json + configure.mjs  write your settings into all 9 workflows at once
- wordpress/seo-engine-rest-fields.php  mu-plugin so module 5 can write the Yoast title and meta
- demo/  the synthetic Search Console + sitemap data (also pinned inside 01-intake-and-data.json)
- NODE-MAP.md, TESTING.md

## Setup
1. Create the Google Sheet (8 tabs from sheets-template/, header row only).
2. cp config.example.json config.json, edit it, then: node configure.mjs
3. Credentials in n8n: Google Sheets OAuth2; a generic OAuth2 credential for Google with the scope
   https://www.googleapis.com/auth/webmasters.readonly (Search Console + URL Inspection); Header Auth "x-api-key"
   for Anthropic; Slack; Basic Auth with a WordPress Application Password; optional Header Auth "Authorization: Bearer ..." for Perplexity.
4. Import, wire the IDs and test: TESTING.md.
