# Testing checklist

Run these in order on a copy of your Google Sheet before you activate anything.

1. Import 08-exceptions.json first, then 01 to 07, then 00-orchestrator.json. Note each workflow's ID (the number in its URL).
2. In 00-orchestrator, replace every REPLACE_WITH_ID_OF_0X with those IDs. In every workflow's settings, set Error workflow to "SEO Engine · 8. Exceptions".
3. Module 1 with demo data: it ships with pinned demo data on the two Search Console nodes and the sitemap node. Add only the Google Sheets credential, click "Test workflow".
   Expect: 11 rows in the pages tab (10 demo pages + /about/, which is in the sitemap with no impressions). /blog/core-web-vitals/ is missing from the sitemap.
4. Module 2 on those rows. Expect 7 rows in opportunities, the first one /blog/meta-description-length/ (low CTR for its position, upside_estimate 509),
   and /blog/internal-linking-strategy/ flagged "positions 8-15 + lost clicks vs previous 28 days".
5. Unpin the demo data in module 1, add the Google OAuth2 credential, run it again on your real property. Check the row count against Search Console > Pages.
6. Module 3 (needs the Anthropic credential). Every brief row should have status "ready". "needs_human" means Claude's answer was not valid JSON: the raw answer is in parse_error.
7. Module 4. Check new_title (60 characters or fewer) and the checks column. You should get one Slack message.
8. Module 5 on a staging site: set one draft to needs_review, run the orchestrator's daily branch by hand. Click Reject first: the draft becomes "rejected". Then repeat and click Approve.
   Check the WordPress post's SEO title, the publish_log row, and that the URL Inspection verdict is filled.
9. Module 6: add a publish_log row for a real page with published_at 18 days ago. Run it: one tracking row with a verdict ("too early" is normal on small pages).
10. Module 7: run it, get the Slack digest, click Reject. Run again, click Approve: one changelog row. The engine never edits its own Config: apply approved changes by hand.
11. Break it on purpose (wrong sheet_id in one module): you should get an exceptions row and a Slack alert.
12. Activate only 00-orchestrator. The modules are called by it and must stay inactive.
