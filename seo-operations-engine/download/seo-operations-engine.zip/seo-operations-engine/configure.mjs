// Writes the values of config.json into the Config node of all 9 workflows.
// Usage: cp config.example.json config.json, edit it, then: node configure.mjs
import fs from 'node:fs';
const cfg = JSON.parse(fs.readFileSync(process.argv[2] || 'config.json', 'utf8'));
for (const f of fs.readdirSync('workflows').filter(f => f.endsWith('.json'))) {
  const p = `workflows/${f}`;
  const wf = JSON.parse(fs.readFileSync(p, 'utf8'));
  for (const n of wf.nodes) {
    if (n.name !== 'Config') continue;
    n.parameters.jsCode = n.parameters.jsCode.replace(/\/\*CONFIG\*\/[\s\S]*?\/\*END\*\//, `/*CONFIG*/ ${JSON.stringify(cfg, null, 2)} /*END*/`);
  }
  fs.writeFileSync(p, JSON.stringify(wf, null, 2));
  console.log('configured', f);
}
