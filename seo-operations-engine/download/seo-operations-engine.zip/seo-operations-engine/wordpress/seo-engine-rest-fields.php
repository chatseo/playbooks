<?php
/**
 * Plugin Name: SEO Engine REST fields
 * Description: Lets the SEO Operations Engine (n8n) write the Yoast SEO title and meta description through the WordPress REST API.
 * Drop this file in wp-content/mu-plugins/. Uses an Application Password (Users > Profile) for the n8n Basic Auth credential.
 * Rank Math instead of Yoast: replace the two keys with rank_math_title and rank_math_description.
 */
add_action('init', function () {
    foreach (['post', 'page'] as $type) {
        foreach (['_yoast_wpseo_title', '_yoast_wpseo_metadesc'] as $key) {
            register_post_meta($type, $key, [
                'show_in_rest'  => true,
                'single'        => true,
                'type'          => 'string',
                'auth_callback' => function () { return current_user_can('edit_posts'); },
            ]);
        }
    }
});
